package com.uniquedeveloper.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/submitTimeOff")
public class SubmitTimeOffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Retrieve form data
        String userEmail = request.getParameter("user-email");
        String timeoffDate = request.getParameter("timeoff-date");
        int timeoffHours = Integer.parseInt(request.getParameter("timeoff-time"));

        RequestDispatcher dispatcher = null;
        // Set the default state for the time off request (you may adjust this as needed)
        String timeoffState = "pending";

        try {
        	Class.forName("com.mysql.jdbc.Driver");
            // Establish database connection
        	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeecheck?useSSL=false","root","root");

            // Insert the time off request into the database
            PreparedStatement pst = con.prepareStatement("INSERT INTO timeoff_requests (toemail, todate, tohours, tostate) VALUES (?, ?, ?, ?)");
            pst.setString(1, userEmail);
            pst.setString(2, timeoffDate);
            pst.setInt(3, timeoffHours);
            pst.setString(4, timeoffState);

            int rowCount = pst.executeUpdate();

            // Close database connection
            con.close();
            
            
			if (rowCount > 0) {
                // Time off request submitted successfully
                request.setAttribute("status", "success");
                String alertScript = "<script>";
        		alertScript += "swal('Success', 'Request Sent', 'success');";
        		alertScript += "</script>";
        		request.setAttribute("alert", alertScript);
                dispatcher = request.getRequestDispatcher("index.jsp");
            } else {
                // Time off request submission failed
                request.setAttribute("status", "failed");
                String alertScript = "<script>";
        		alertScript += "swal('Error', 'Try Againg', 'error');";
        		alertScript += "</script>";
        		request.setAttribute("alert", alertScript);
                dispatcher = request.getRequestDispatcher("index.jsp"); // or any other appropriate page
            }
			dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("status", "failed");
            dispatcher = request.getRequestDispatcher("index.jsp");
        }

        // Redirect back to the index.jsp or any other appropriate page
	}

}
