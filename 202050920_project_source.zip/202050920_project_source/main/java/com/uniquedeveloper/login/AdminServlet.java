 package com.uniquedeveloper.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/timeofflistload")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Establish database connection
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeecheck?useSSL=false",
                    "root", "root");

            // Retrieve pending time off requests from the database
            PreparedStatement pst = con.prepareStatement(
                    "SELECT toid, toemail, todate, tohours, tostate FROM timeoff_requests WHERE tostate = 'pending'");
            ResultSet rs = pst.executeQuery();

            // Create a list to store pending time off requests
            List<TimeOffRequest> timeOffRequests = new ArrayList<>();

            // Iterate over the result set and add each pending time off request to the list
            while (rs.next()) {
                TimeOffRequest timeOffRequest = new TimeOffRequest(
                        rs.getInt("toid"),
                        rs.getString("toemail"),
                        rs.getString("todate"),
                        rs.getInt("tohours"),
                        rs.getString("tostate")
                );
                timeOffRequests.add(timeOffRequest);
            }

            // Close database connection
            con.close();

            // Set the pending time off requests as a request attribute
            request.setAttribute("timeOffRequests", timeOffRequests);

            // Forward the request to admin.jsp for rendering
            RequestDispatcher dispatcher = request.getRequestDispatcher("admin.jsp");
            dispatcher.forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle database errors
            response.getWriter().write("Error retrieving pending time off requests");
        }
    }
}
