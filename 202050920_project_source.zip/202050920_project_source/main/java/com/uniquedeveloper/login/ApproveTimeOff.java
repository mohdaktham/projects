package com.uniquedeveloper.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ApproveTimeOff")
public class ApproveTimeOff extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String requestId = request.getParameter("admin-input");

        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeecheck?useSSL=false", "root", "root");

            // Update the time off request state to 'approved' using the toid
            PreparedStatement updateStmt = con.prepareStatement("UPDATE timeoff_requests SET tostate = 'approved' WHERE toid = ?");
            updateStmt.setString(1, requestId);
            int rowsAffected = updateStmt.executeUpdate();
            
            PreparedStatement updateHoursStmt = con.prepareStatement("UPDATE users SET time_off_hours = time_off_hours + (SELECT tohours FROM timeoff_requests WHERE toid = ?) WHERE uemail = (SELECT toemail FROM timeoff_requests WHERE toid = ?)");
            updateHoursStmt.setString(1, requestId);
            updateHoursStmt.setString(2, requestId);
            updateHoursStmt.executeUpdate();
            if (rowsAffected > 0) {
                // Time off request approved successfully
                response.sendRedirect("admin.jsp"); // Redirect to admin.jsp after processing
            } else {
                // No time off request found with the given ID
                response.getWriter().write("Error: Time off request not found");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle any exceptions
            response.getWriter().write("Error: Failed to approve time off request");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}


