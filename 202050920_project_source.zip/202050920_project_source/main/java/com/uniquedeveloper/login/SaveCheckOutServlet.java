package com.uniquedeveloper.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
//import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SaveCheckOutServlet")
public class SaveCheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String checkOutTime = request.getParameter("checkout-time");
        String userEmail = request.getParameter("user-email");
        
        Connection con = null;
        RequestDispatcher dispatcher = null;
        
        if(checkOutTime.isBlank()) {
        	request.setAttribute("status","failed");

			// Add SweetAlert
            String alertScript = "<script>";
            alertScript += "swal('Error', 'Invalid Input', 'error');";
            alertScript += "</script>";
            request.setAttribute("alert", alertScript);
            
            dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
        }
        
        
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeecheck?useSSL=false","root","root");
            PreparedStatement checkInStmt = con.prepareStatement("SELECT check_in FROM users WHERE uemail = ?");
            checkInStmt.setString(1, userEmail);
            
            ResultSet resultCheckIn = checkInStmt.executeQuery();
        
            if(resultCheckIn.next()) {
            	String checkInTime = resultCheckIn.getString("check_in");
            	
            	if(checkInTime != null) {
            	
	            	LocalDateTime localcheckInTime = LocalDateTime.parse(checkInTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	            	LocalDateTime localcheckOutTime = LocalDateTime.parse(checkOutTime, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
	
	            	System.out.println("check In : "+ localcheckInTime);
	            	System.out.println("check out : "+ localcheckOutTime);
	            	
	            	// Compare check-out time with check-in time
	                if (localcheckOutTime.isAfter(localcheckInTime)) {
	                    // Calculate the time difference
	                    Duration duration = Duration.between(localcheckInTime, localcheckOutTime);
	                    int hours = (int) duration.toHours();
	//                    long minutes = duration.toMinutesPart();
	                    System.out.println("today Hours : "+ hours);
	                    
	                    PreparedStatement hourgetstmt = con.prepareStatement("SELECT work_hours FROM users WHERE uemail = ?");
	                    hourgetstmt.setString(1, userEmail);
	                    
	                    ResultSet resultgethours = hourgetstmt.executeQuery();
	                    
	                    if(resultgethours.next()) {
	                    	
	                    	PreparedStatement updatehourstmt = con.prepareStatement("UPDATE users SET work_hours = ? WHERE uemail = ?");
	                    	int rowCount = 0;
	                    	String prevworkhour = resultgethours.getString("work_hours");
	                    	if(prevworkhour != null) {
	                    		int prevworkhournumber = Integer.parseInt(prevworkhour);
	                    		System.out.println("prevworkhour : "+ prevworkhournumber);
	                    		int updatedHours = prevworkhournumber + hours;
	                    		System.out.println("updatedHours : "+ updatedHours);
	                    		
	                    		updatehourstmt.setInt(1,updatedHours);
	                    		updatehourstmt.setString(2, userEmail);
	                    		
	                    		rowCount = updatehourstmt.executeUpdate();
	                    	}else {
	                    		updatehourstmt.setInt(1,hours);
	                    		updatehourstmt.setString(2, userEmail);
	                    		
	                    		rowCount = updatehourstmt.executeUpdate();
	                    	}
	                    	
	                    	if(rowCount > 0) {
	                        	System.out.println("Hour Update successful: " + rowCount + " rows updated.");
	                        	request.setAttribute("status","success");
	                        	
	                        	PreparedStatement setnullcheckinstmt = con.prepareStatement("UPDATE users SET check_in = NULL WHERE uemail = ?");
	                        	setnullcheckinstmt.setString(1, userEmail);
	                        	int nullUpdateCount = setnullcheckinstmt.executeUpdate();
	                        	
	                        	if(nullUpdateCount>0) {
	                        		// Add SweetAlert
	                        		String alertScript = "<script>";
	                        		alertScript += "swal('Success', 'Checked Out', 'success');";
	                        		alertScript += "</script>";
	                        		request.setAttribute("alert", alertScript);                        		
	                        	}
	            			} else {
	            				System.out.println("No rows were updated.");
	            				request.setAttribute("status","failed");
	            			
	            				// Add SweetAlert
	                            String alertScript = "<script>";
	                            alertScript += "swal('Error', 'Hour couldn't added', 'error');";
	                            alertScript += "</script>";
	                            request.setAttribute("alert", alertScript);
	            			}
	                    	
	                    	
	                    	
	                    }else {
	                    	System.out.println("prevworkhour haven't ");
	                    } 
	                    
	                } else {
	                    System.out.println("Check-out time does not come after check-in time.");
	                    request.setAttribute("status","failed");
	    				
	    				// Add SweetAlert
	                    String alertScript = "<script>";
	                    alertScript += "swal('Error', 'Invalid Input', 'error');";
	                    alertScript += "</script>";
	                    request.setAttribute("alert", alertScript);
	                }
	            	
	            	
	            	request.setAttribute("status","success");
            	}else{
            		request.setAttribute("status","failed");
	    				
    				// Add SweetAlert
                    String alertScript = "<script>";
                    alertScript += "swal('Error', 'Not Checked In', 'error');";
                    alertScript += "</script>";
                    request.setAttribute("alert", alertScript);
            	}
            }else {
            	System.out.println("not available");
            	
            	request.setAttribute("status","failed");
				
				// Add SweetAlert
                String alertScript = "<script>";
                alertScript += "swal('Error', 'Not Checked In', 'error');";
                alertScript += "</script>";
                request.setAttribute("alert", alertScript);
            }
            
            
            
            dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
            
        }catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception called");
            
            dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);

        }
        
	}

}
