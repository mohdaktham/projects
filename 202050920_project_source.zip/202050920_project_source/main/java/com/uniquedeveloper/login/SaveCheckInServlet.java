package com.uniquedeveloper.login;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SaveCheckInServlet")
public class SaveCheckInServlet extends HttpServlet {
   
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String checkInTime = request.getParameter("checkin-time");
        String userEmail = request.getParameter("user-email");
        
        Connection con = null;
        RequestDispatcher dispatcher = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeecheck?useSSL=false","root","root");
            PreparedStatement selectStmt = con.prepareStatement("SELECT check_in FROM users WHERE uemail = ?");
          
            selectStmt.setString(1, userEmail);
            ResultSet rs = selectStmt.executeQuery();
          
            int rowCount = 0;
            
            if (rs.next() && rs.getTimestamp("check_in") != null) {
                // There's already a value in the "check_in" column
                // Handle this case as required
                System.out.println("There's already a value in the 'check_in' column.");
            }else {
            	PreparedStatement pst = con.prepareStatement("UPDATE users SET check_in = ? WHERE uemail = ?");
            	pst.setString(1, checkInTime);
            	pst.setString(2, userEmail);
            	
            	rowCount = pst.executeUpdate();
            }
            
            


            if(rowCount > 0) {
            	System.out.println("Update successful: " + rowCount + " rows updated.");
            	request.setAttribute("status","success");
            	
            	// Add SweetAlert
                String alertScript = "<script>";
                alertScript += "swal('Success', 'Record added successfully', 'success');";
                alertScript += "</script>";
                request.setAttribute("alert", alertScript);
			} else {
				System.out.println("No rows were updated.");
				request.setAttribute("status","failed");
				
				// Add SweetAlert
                String alertScript = "<script>";
                alertScript += "swal('Error', 'Already Checked In', 'error');";
                alertScript += "</script>";
                request.setAttribute("alert", alertScript);
			}
            
            dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
            

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("status","failed");
			
			// Add SweetAlert
            String alertScript = "<script>";
            alertScript += "swal('Error', 'Invalid Input', 'error');";
            alertScript += "</script>";
            request.setAttribute("alert", alertScript);
            
            dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);

        }
        finally{
        	try {
        		con.close();
        	} catch (SQLException e) {
        		e.printStackTrace();
        	}        	
        }
    }
}

