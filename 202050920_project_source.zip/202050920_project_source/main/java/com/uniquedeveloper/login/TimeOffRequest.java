package com.uniquedeveloper.login;

public class TimeOffRequest {
    private int toid;
    private String email;
    private String date;
    private int hours;
    private String state;

    public TimeOffRequest(int toid, String email, String date, int hours, String state) {
        this.toid = toid;
        this.email = email;
        this.date = date;
        this.hours = hours;
        this.state = state;
    }

    public int getToid() {
        return toid;
    }

    public String getEmail() {
        return email;
    }

    public String getDate() {
        return date;
    }

    public int getHours() {
        return hours;
    }

    public String getState() {
        return state;
    }
}